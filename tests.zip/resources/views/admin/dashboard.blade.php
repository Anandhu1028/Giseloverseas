@extends('layouts.admin.app')
@section('content')
<div class="dashboard-main-body">
 
</div>

  <div class="container-fluid p-0 mx-auto" style="max-width: 1140px;">
  <div class="card h-100 p-0 radius-12 overflow-hidden">
    <div class="card-body p-24">
      <div class="tab-content" id="pills-tabContent">
        <div class="tab-pane fade show active" id="pills-all" role="tabpanel" aria-labelledby="pills-all-tab" tabindex="0">
          <div class="row gy-4">
                     
                      <div class="col-xxl-3 col-md-4 col-sm-6">
                          <div class="hover-scale-img border radius-16 overflow-hidden">
                              <div class="max-h-266-px overflow-hidden">
                                  <img src="{{asset('assets/img/img-1.jpg')}}" alt="" class="hover-scale-img__img w-100 h-100 object-fit-cover">
                              </div>
                              <div class="py-16 px-24">
                                  <h6 class="mb-4">This is Image title</h6>
                                  <p class="mb-0 text-sm text-secondary-light">UI Design</p>
                              </div>
                          </div>
                      </div>
                      <div class="col-xxl-3 col-md-4 col-sm-6">
                          <div class="hover-scale-img border radius-16 overflow-hidden">
                              <div class="max-h-266-px overflow-hidden">
                                  <img src="{{asset('assets/img/img-1.jpg')}}" alt="" class="hover-scale-img__img w-100 h-100 object-fit-cover">
                              </div>
                              <div class="py-16 px-24">
                                  <h6 class="mb-4">This is Image title</h6>
                                  <p class="mb-0 text-sm text-secondary-light">UI Design</p>
                              </div>
                          </div>
                      </div>
                      <div class="col-xxl-3 col-md-4 col-sm-6">
                          <div class="hover-scale-img border radius-16 overflow-hidden">
                              <div class="max-h-266-px overflow-hidden">
                                  <img src="{{asset('assets/img/img-1.jpg')}}" alt="" class="hover-scale-img__img w-100 h-100 object-fit-cover">
                              </div>
                              <div class="py-16 px-24">
                                  <h6 class="mb-4">This is Image title</h6>
                                  <p class="mb-0 text-sm text-secondary-light">UI Design</p>
                              </div>
                          </div>
                      </div>
                      <div class="col-xxl-3 col-md-4 col-sm-6">
                          <div class="hover-scale-img border radius-16 overflow-hidden">
                              <div class="max-h-266-px overflow-hidden">
                                  <img src="{{asset('assets/img/img-1.jpg')}}" alt="" class="hover-scale-img__img w-100 h-100 object-fit-cover">
                              </div>
                              <div class="py-16 px-24">
                                  <h6 class="mb-4">This is Image title</h6>
                                  <p class="mb-0 text-sm text-secondary-light">UI Design</p>
                              </div>
                          </div>
                      </div>
                      <div class="col-xxl-3 col-md-4 col-sm-6">
                          <div class="hover-scale-img border radius-16 overflow-hidden">
                              <div class="max-h-266-px overflow-hidden">
                                  <img src="{{asset('assets/img/img-1.jpg')}}" alt="" class="hover-scale-img__img w-100 h-100 object-fit-cover">
                              </div>
                              <div class="py-16 px-24">
                                  <h6 class="mb-4">This is Image title</h6>
                                  <p class="mb-0 text-sm text-secondary-light">UI Design</p>
                              </div>
                          </div>
                      </div>
                      <div class="col-xxl-3 col-md-4 col-sm-6">
                          <div class="hover-scale-img border radius-16 overflow-hidden">
                              <div class="max-h-266-px overflow-hidden">
                                  <img src="{{asset('assets/img/img-1.jpg')}}" alt="" class="hover-scale-img__img w-100 h-100 object-fit-cover">
                              </div>
                              <div class="py-16 px-24">
                                  <h6 class="mb-4">This is Image title</h6>
                                  <p class="mb-0 text-sm text-secondary-light">UI Design</p>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div> 
 </div>
@endsection