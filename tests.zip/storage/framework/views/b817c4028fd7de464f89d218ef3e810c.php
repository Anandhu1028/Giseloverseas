
<?php $__env->startSection('content'); ?>

<div class="main-slider slider-pro wow" id="my-slider"
				data-slider-width="1600"
				data-slider-height="850">
				

				<div class="sp-slides">

					<!-- Slide 1 -->
					<div class="sp-slide">
						<img class="sp-image img-responsive" src="<?php echo e(asset('assets/media/main-slider/1.jpg')); ?>" alt="slider">

						<div class="sp-layer main-slider__title hidden-xs"
								data-horizontal="0"
								data-vertical="36%"
								data-width="100%"
								data-show-transition="left"
								data-hide-transition="right"
								data-show-duration="800"
								data-show-delay="400"
								data-hide-delay="400">
								<div class="container">
									We Provide Highest Quality
								</div>
						</div>

						<div class="sp-layer"
								data-horizontal="0"
								data-vertical="43%"
								data-width="100%"
								data-show-transition="right"
								data-hide-transition="left"
								data-show-duration="800"
								data-show-delay="1000"
								data-hide-delay="400">
								<div class="container">
									<div class="main-slider__subtitle">Fast & Flexible Road Freight Services</div>
									<div class="decor-2 decor-2_mod-a decor-2_mod_white"></div>
								</div>
						</div>

						<div class="sp-layer main-slider__text"
								data-horizontal="0"
								data-vertical="55%"
								data-width="100%"
								data-height="30%"
								data-show-transition="up"
								data-hide-transition="buttom"
								data-show-duration="800"
								data-show-delay="2000"
								data-hide-delay="1200">
								<div class="container">
									<p class="hidden-xs"> Gisel Overseas Fast and flexible road freight services, ensuring timely and reliable deliveries every time</p>
								
								</div>
						</div>
					</div>
					<!-- end sp-slide -->

					<!-- Slide 2 -->
					<div class="sp-slide">
						<img class="sp-image img-responsive" src="<?php echo e(asset('assets/media/main-slider/2.jpg')); ?>" alt="slider">

						<div class="sp-layer main-slider__title hidden-xs"
								data-horizontal="0"
								data-vertical="36%"
								data-width="100%"
								data-show-transition="left"
								data-hide-transition="right"
								data-show-duration="800"
								data-show-delay="400"
								data-hide-delay="400">
								<div class="container">
									We Provide Highest Quality
								</div>
						</div>

						<div class="sp-layer"
								data-horizontal="0"
								data-vertical="43%"
								data-width="100%"
								data-show-transition="right"
								data-hide-transition="left"
								data-show-duration="800"
								data-show-delay="1000"
								data-hide-delay="400">
								<div class="container">
									<div class="main-slider__subtitle">  Ocean Freight Expertise</div>
									<div class="decor-2 decor-2_mod-a decor-2_mod_white"></div>
								</div>
						</div>

						<div class="sp-layer main-slider__text"
								data-horizontal="0"
								data-vertical="55%"
								data-width="100%"
								data-height="30%"
								data-show-transition="up"
								data-hide-transition="buttom"
								data-show-duration="800"
								data-show-delay="2000"
								data-hide-delay="1200">
								<div class="container">
									<p class="hidden-xs"> Gisel Overseas  Navigate the world with our ocean freight expertise Reliable global shipping solutions</p>
								</div>
						</div>
					</div>
					<!-- end sp-slide -->

					<!-- Slide 3 -->
					<div class="sp-slide">
						<img class="sp-image img-responsive" src="<?php echo e(asset('assets/media/main-slider/3.jpg')); ?>" alt="slider">

						<div class="sp-layer main-slider__title hidden-xs"
								data-horizontal="0"
								data-vertical="36%"
								data-width="100%"
								data-show-transition="left"
								data-hide-transition="right"
								data-show-duration="800"
								data-show-delay="400"
								data-hide-delay="400">
								<div class="container">
									We Provide Highest Quality
								</div>
						</div>

						<div class="sp-layer"
								data-horizontal="0"
								data-vertical="43%"
								data-width="100%"
								data-show-transition="right"
								data-hide-transition="left"
								data-show-duration="800"
								data-show-delay="1000"
								data-hide-delay="400">
								<div class="container">
									<div class="main-slider__subtitle">Swift Deliveries, Anytime, Anywhere</div>
									<div class="decor-2 decor-2_mod-a decor-2_mod_white"></div>
								</div>
						</div>

						<div class="sp-layer main-slider__text"
								data-horizontal="0"
								data-vertical="55%"
								data-width="100%"
								data-height="30%"
								data-show-transition="up"
								data-hide-transition="buttom"
								data-show-duration="800"
								data-show-delay="2000"
								data-hide-delay="1200">
								<div class="container">
									<p class="hidden-xs"> Gisel Overseas  Count on fast, reliable air freight services worldwide</p>
								</div>
						</div>
					</div>
					<!-- end sp-slide -->

					<!-- Slide 4 -->
					<div class="sp-slide">
						<img class="sp-image img-responsive" src="<?php echo e(asset('assets/media/main-slider/4.jpg')); ?>" alt="slider">

						<div class="sp-layer main-slider__title hidden-xs"
								data-horizontal="0"
								data-vertical="36%"
								data-width="100%"
								data-show-transition="left"
								data-hide-transition="right"
								data-show-duration="800"
								data-show-delay="400"
								data-hide-delay="400">
								<div class="container">
									We Provide Highest Quality
								</div>
						</div>

						<div class="sp-layer"
								data-horizontal="0"
								data-vertical="43%"
								data-width="100%"
								data-show-transition="right"
								data-hide-transition="left"
								data-show-duration="800"
								data-show-delay="1000"
								data-hide-delay="400">
								<div class="container">
									<div class="main-slider__subtitle">Secure, Reliable, Flexible Warehouse</div>
									<div class="decor-2 decor-2_mod-a decor-2_mod_white"></div>
								</div>
						</div>

						<div class="sp-layer main-slider__text"
								data-horizontal="0"
								data-vertical="55%"
								data-width="100%"
								data-height="30%"
								data-show-transition="up"
								data-hide-transition="buttom"
								data-show-duration="800"
								data-show-delay="2000"
								data-hide-delay="1200">
								<div class="container">
									<p class="hidden-xs">Secure, reliable, flexible warehouse services for safe storage and easy access</p>
								</div>
						</div>
					</div>
					<!-- end sp-slide -->

				</div>

				<div class="sp-thumbnails">
					<a href="<?php echo e(route('login')); ?>">
						<div class="sp-thumbnail">
						  <span class="sp-thumbnail-icon">
							<i class="fas fa-sign-in-alt"></i>
						  </span>
						</div>
					  </a>
					  
					
					
				</div>

				<!-- end sp-slides -->
			</div><!-- end main-slider -->


			
				<section class="section-area">
					<div class="section-bg_mod-a section-title-block wow">
						<div class="container">
							<div class="row">
								<div class="col-xs-12">
									<h2 class="ui-title-block"><span class="ui-title-emphasis">international freight and</span> logistics services</h2>
									<div class="decor-1"><i class='icon flaticon-delivery36'></i></div>
								</div>
							</div>
						</div>
					</div>
				
					<div class="section-top-minus wow">
						<div class="container">
							<div class="row">
								<div class="col-xs-12" >
									<div class="owl-carousel owl-theme enable-owl-carousel"
										 data-min480="1"
										 data-min768="2"
										 data-min992="4" 
										 data-min1200="4"
										 data-pagination="false"
										 data-navigation="false"
										 data-auto-play="4000"
										 data-stop-on-hover="true">
				
										<div class="block-services">
											<h3 class="block-services__title ui-title-inner">Road Freight Service</h3>
											<div class="block-services__description">We provide efficient and reliable road freight services, ensuring timely delivery of goods across local and regional routes. Our experienced drivers and well-maintained fleet guarantee safe transport tailored to your logistics needs.</div>
											<div class="decor-3"></div>
											<a class="block-services__link btn-link" href="blog-post.html">read more</a>
										</div>
				
										<div class="block-services"> 
											<h3 class="block-services__title ui-title-inner">Ocean Freight Service</h3>
											<div class="block-services__description">Ocean Freight offers reliable and efficient logistics solutions for importing and exporting goods worldwide. With a focus on customer satisfaction, we ensure safe transport and timely delivery, leveraging our global network and expertise in international trade.</div>
											<div class="decor-3"></div>
											<a class="block-services__link btn-link" href="blog-post.html">read more</a>
										</div>
				
										<div class="block-services">
											<h3 class="block-services__title ui-title-inner">Air Freight Service</h3>
											<div class="block-services__description">Air freight services, ensuring swift delivery of goods across global markets. Our experienced team manages all logistics, from customs clearance to final delivery, prioritizing efficiency and customer satisfaction.</div>
											<div class="decor-3"></div>
											<a class="block-services__link btn-link" href="blog-post.html">read more</a>
										</div>
				
										<div class="block-services">
											<h3 class="block-services__title ui-title-inner">Warehouse Service</h3>
											<div class="block-services__description">Secure and efficient warehouse services tailored to your logistics needs. Our facilities are equipped for inventory management, order fulfillment, and safe storage, ensuring your goods are handled with care and ready for timely distribution.</div>
											<div class="decor-3"></div>
											<a class="block-services__link btn-link" href="blog-post.html">read more</a>
										</div>
									</div><!-- end slider -->
								</div>
							</div>
						</div><!-- end row -->
					</div><!-- end container -->
				</section><!-- end section-->
				
			

			<section class="section-default wow">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<h2 class="ui-title-block ui-title-block_mod-a">Our Business Mission <span class="decor-4 decor-4_mod-a"><i class="icon flaticon-logistics3 color-primary"></i></span> is Client’s Satisfaction</h2>

							<div class="owl-carousel owl-theme owl-theme_mod-b enable-owl-carousel"
								data-pagination="false"
								data-navigation="false"
								data-single-item="true"
								data-auto-play="7000"
								data-transition-style="fade"
								data-main-text-animation="true"
								data-after-init-delay="3000"
								data-after-move-delay="1000"
								data-stop-on-hover="true">

								<div class="reviews">
									<div class="reviews__text">Our mission is to ensure client satisfaction through reliable logistics solutions in the import-export industry. We connect global markets with timely deliveries and prioritize transparency and innovation to exceed client expectations</div>
									<div class="reviews__author">
									
									</div>
								</div>

								<div class="reviews">
									<div class="reviews__text">Amet consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua enim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip exea commodo consequat duis aute dolor reprehenderit in voluptate</div>
									<div class="reviews__author">
										
									</div>
								</div>

							</div><!-- end slider -->
						</div><!-- end col -->
					</div><!-- end row -->
				</div><!-- end container -->
			</section><!-- end section-default -->


			<div class="container wow">
				<div class="row">
					<div class="col-xs-12">
						<div class="section-progress clearfix">
							

							<div class="progress-center">
								<img class="center-block img-responsive" src="<?php echo e(asset('assets/media/bg/bg-1.jpg')); ?>" alt="background">
								
							</div>
						</div><!-- end section-progress -->
					</div><!-- end col -->
				</div><!-- end row -->
			</div><!-- end container -->


			


			<section class="section-default wow">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<h2 class="ui-title-block"><span class="ui-title-emphasis">why choose us</span>the main features</h2>
							<div class="decor-1"><i class='icon flaticon-delivery36'></i></div>
							<div class="ui-subtitle-block ui-subtitle-block_mod-a">We prioritize reliability and expertise in logistics. Our skilled team ensures timely deliveries and offers tailored solutions to optimize your supply chain

							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-5 col-sm-7">
							<ul class="list-features list-features_mod-b list-unstyled">
								<li class="list-features__item">
									<i class="list-features__icon flaticon-head39"></i>
									<div class="list-features__inner">
										<h3 class="list-features__title ui-title-inner">100% satisfied customers</h3>
										<div class="list-features__description"> We pride ourselves on delivering exceptional logistics services that meet the highest standards</div>
									</div>
								</li>
								<li class="list-features__item">
									<i class="list-features__icon flaticon-delivery56"></i>
									<div class="list-features__inner">
										<h3 class="list-features__title ui-title-inner">quality service affordable price</h3>
										<div class="list-features__description"> We believe that exceptional logistics services should be accessible to everyone</div>
									</div>
								</li>
								<li class="list-features__item">
									<i class="list-features__icon flaticon-world77"></i>
									<div class="list-features__inner">
										<h3 class="list-features__title ui-title-inner">worldwide locations</h3>
										<div class="list-features__description">We operate on a global scale, providing logistics solutions that connect you to markets around the world</div>
									</div>
								</li>
								<li class="list-features__item">
									<i class="list-features__icon flaticon-transport643"></i>
									<div class="list-features__inner">
										<h3 class="list-features__title ui-title-inner">modern vehicles fleet</h3>
										<div class="list-features__description"> Ee take pride in our state-of-the-art vehicle fleet, designed to meet the demands of today’s logistics </div>
									</div>
								</li>
							</ul>
						</div>
						<div class="col-md-7 col-sm-5">
							<img class="img-responsive" src="<?php echo e(asset('assets/media/bg/bg-2.jpg')); ?>" alt="Foto">
						</div>
					</div>
				</div>
			</section><!-- end section -->


			


			




			<div class="section-bg_mod-b section_mod-a wow"></div>
				<div class="container">
					<div class="row">
						<div class="col-md-6">
							<section class="section-area">
								<h2 class="ui-title-block ui-title-block_w_bg ui-title-block_w_bg-first"><span class="ui-title-block__inner">request a quote</span></h2>

								<form class="form-request form-request_mod-a ui-form block_right_pad" action="#" method="post">
									<div class="row">
										<div class="col-xs-12">
											<input class="form-control" type="text" placeholder="Full Name">
										</div>
										<div class="col-xs-12">
											<input class="form-control" type="email" placeholder="Email address">
										</div>
									</div>

									<div class="row">
										<div class="col-sm-6">
											<div class="select-control">
												<select class="selectpicker">
													<option>Destination From....</option>
													<option>1</option>
													<option>2</option>
												</select>
											</div>
										</div>
										<div class="col-sm-6">
											<div class="select-control">
												<select class="selectpicker">
													<option>Destinatin To....</option>
													<option>1</option>
													<option>2</option>
												</select>
											</div>
										</div>
									</div>

									<div class="row">
										<div class="col-sm-6">
											<div class="select-control">
												<select class="selectpicker">
													<option>Logistics Type</option>
													<option>1</option>
													<option>2</option>
												</select>
											</div>
										</div>
										<div class="col-sm-6">
											<input class="form-control" type="email" placeholder="Subject">
										</div>
									</div>

									<div class="row">
										<div class="col-xs-12">
											<textarea class="form-control" rows="11" placeholder="message"></textarea>
											<button class="ui-form__btn btn btn-sm btn_mod-a btn-effect"><span class="btn__inner">request quote</span></button>
										</div>
									</div>
								</form>
							</section>
							<div class="decor-4 decor-4_mod-b"><i class="icon flaticon-logistics3 color-primary"></i></div>
						</div>

						<div class="col-md-6">
							<section class="section-area">
								<h2 class="ui-title-block ui-title-block_w_bg ui-title-block_w_bg-last ui-title-block_w_bg-primary"><span class="ui-title-block__inner">general faq’s</span></h2>

								<div class="block_left_pad">
									<div class="panel-group accordion" id="accordion-1">
										<div class="panel">
											<div class="panel-heading">
												<a class="btn-collapse collapsed" data-toggle="collapse" data-parent="#accordion-1" href="#collapse-1"><i class="icon"></i><span class="helper-2"></span></a>
												<h3 class="panel-title ui-title-inner">What documents are required for importing/exporting?</h3>
												<div class="decor-2 decor-2_mod-b"></div>
											</div>
											<div id="collapse-1" class="panel-collapse collapse">
												<div class="panel-body">
													<p>The required documents may include a commercial invoice, bill of lading, packing list, and any necessary permits or licenses. Our team can assist you in understanding the specific requirements for your shipment.</p>
												</div>
											</div>
										</div><!-- end panel -->

										<div class="panel panel-default">
											<div class="panel-heading">
												<a class="btn-collapse" data-toggle="collapse" data-parent="#accordion-1" href="#collapse-2"><i class="icon"></i><span class="helper-2"></span></a>
												<h3 class="panel-title ui-title-inner">How do I track my shipment?</h3>
												<div class="decor-2 decor-2_mod-b"></div>
											</div>
											<div id="collapse-2" class="panel-collapse collapse in">
												<div class="panel-body">
													<p>You can track your shipment by entering your tracking number on our website or by contacting our customer service team for assistance.</p>
												</div>
											</div>
										</div><!-- end panel -->

										

									<div class="panel">
										<div class="panel-heading">
											<a class="btn-collapse collapsed" data-toggle="collapse" data-parent="#accordion-1" href="#collapse-3"><i class="icon"></i><span class="helper-2"></span></a>
											<h3 class="panel-title ui-title-inner">Do you handle customs clearance?</h3>
											<div class="decor-2 decor-2_mod-b"></div>
										</div>
										<div id="collapse-4" class="panel-collapse collapse">
											<div class="panel-body">
												<p>Yes, we have a dedicated customs clearance team to help ensure that your shipments comply with all regulations and are cleared efficiently.</p>
											</div>
										</div>
									</div><!-- end panel -->

										<div class="panel">
											<div class="panel-heading">
												<a class="btn-collapse collapsed" data-toggle="collapse" data-parent="#accordion-1" href="#collapse-4"><i class="icon"></i><span class="helper-2"></span></a>
												<h3 class="panel-title ui-title-inner">How can I ensure my goods are safely packaged for shipping?</h3>
												<div class="decor-2 decor-2_mod-b"></div>
											</div>
											<div id="collapse-4" class="panel-collapse collapse">
												<div class="panel-body">
													<p>We recommend using sturdy materials, proper cushioning, and clear labeling. Our team can provide guidance on best practices for packaging your goods.</p>
												</div>
											</div>
										</div><!-- end panel -->
									</div><!-- end accordion -->
									<div class="note text-center">If you didn’t found the answer to your question here, Contact us <br>& our representative will reply you as soon as poossible, usually within 24 hours!</div>
									<div class="decor-3 text-center"></div>
									<div class="text-center"><a class="btn-link btn-link_lg" href="home.html">get in touch</a></div>

								</div>

							</section>
						</div>
					</div>
				</div>
			</div><!-- end section -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Gisel Overseas\giseloverseas\resources\views/frontend/index.blade.php ENDPATH**/ ?>