<!-- SCRIPTS MAIN -->

<script src="<?php echo e(asset('assets/js/jquery-migrate-1.2.1.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('../../../cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/modernizr.custom.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/cssua.min.js')); ?>"></script>


<!--SCRIPTS THEME-->

<!-- Home slider -->
<script src="<?php echo e(asset('assets/plugins/slider-pro/dist/js/jquery.sliderPro.js')); ?>"></script>
<!-- Sliders -->
<script src="<?php echo e(asset('assets/plugins/owl-carousel/owl.carousel.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/plugins/flexslider/jquery.flexslider.js')); ?>"></script>
<!-- Modal -->
<script src="<?php echo e(asset('assets/plugins/prettyphoto/js/jquery.prettyPhoto.js')); ?>"></script>
<!-- Select customization -->
<script src="<?php echo e(asset('assets/plugins/bootstrap-select/dist/js/bootstrap-select.js')); ?>"></script>
<!-- Chart -->
<script src="<?php echo e(asset('assets/plugins/rendro-easy-pie-chart/dist/jquery.easypiechart.min.js')); ?>"></script>
<!-- Animation -->
<script src="<?php echo e(asset('assets/plugins/scrollreveal/dist/scrollreveal.min.js')); ?>"></script>
<!-- Menu for android-->
<script src="<?php echo e(asset('assets/js/doubletaptogo.js')); ?>"></script>

<!-- Custom -->
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>
<!-- jQuery library js -->
<script src="<?php echo e(asset('accounts/assets/js/lib/jquery-3.7.1.min.js')); ?>"></script>
<!-- Bootstrap js -->
<script src="<?php echo e(asset('accounts/assets/js/lib/bootstrap.bundle.min.js')); ?>"></script>
<!-- Apex Chart js -->
<script src="<?php echo e(asset('accounts/assets/js/lib/apexcharts.min.js')); ?>"></script>
<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<!-- Data Table js -->
<script src="<?php echo e(asset('accounts/assets/js/lib/dataTables.min.js')); ?>"></script>
<!-- Iconify Font js -->
<script src="<?php echo e(asset('accounts/assets/js/lib/iconify-icon.min.js')); ?>"></script>
<!-- jQuery UI js -->
<script src="<?php echo e(asset('accounts/assets/js/lib/jquery-ui.min.js')); ?>"></script>
<!-- Vector Map js -->
<script src="<?php echo e(asset('accounts/assets/js/lib/jquery-jvectormap-2.0.5.min.js')); ?>"></script>
<script src="<?php echo e(asset('accounts/assets/js/lib/jquery-jvectormap-world-mill-en.js')); ?>"></script>
<!-- Popup js -->
<script src="<?php echo e(asset('accounts/assets/js/lib/magnifc-popup.min.js')); ?>"></script>
<!-- Slick Slider js -->
<script src="<?php echo e(asset('accounts/assets/js/lib/slick.min.js')); ?>"></script>
<!-- prism js -->
<script src="<?php echo e(asset('accounts/assets/js/lib/prism.js')); ?>"></script>
<!-- file upload js -->
<script src="<?php echo e(asset('accounts/assets/js/lib/file-upload.js')); ?>"></script>
<!-- audioplayer -->
<script src="<?php echo e(asset('accounts/assets/js/lib/audioplayer.js')); ?>"></script>

<!-- main js -->
<script src="<?php echo e(asset('accounts/assets/js/app.js')); ?>"></script>

<!-- App-specific scripts -->
<script src="<?php echo e(asset('accounts/assets/js/homeOneChart.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/lineChartPageChart.js')); ?>"></script>

<!-- Additional scripts from views -->

<?php echo $__env->yieldContent('script'); ?>
<?php /**PATH C:\xampp\htdocs\Gisel Overseas\giseloverseas\resources\views/layouts/frontend/script.blade.php ENDPATH**/ ?>