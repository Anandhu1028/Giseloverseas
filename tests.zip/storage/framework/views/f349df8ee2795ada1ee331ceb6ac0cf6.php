
<?php $__env->startSection('content'); ?>

<div class="container-fluid p-0 mx-auto mt-5" style="max-width: 1140px;">
  <div class="card h-100 p-0 radius-12 overflow-hidden">
    <div class="card-body p-24">
      <div class="tab-content" id="pills-tabContent">
        <div class="tab-pane fade show active" id="pills-all" role="tabpanel" aria-labelledby="pills-all-tab" tabindex="0">
          <div class="row gy-4">
            <div class="card-body">
              <div class="table-responsive">
                <table class="table bordered-table mb-0">
                  <a href="" class="btn-primary">Add</a>
                  <thead>
                    <tr>
                      <th scope="col">Image</th>
                      <th scope="col">Title</th>
                      <th scope="col">description</th>
                      <th scope="col">Action</th>
                      
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <div class="d-flex align-items-center">
                          <img src="assets/images/users/user1.png" alt="" class="flex-shrink-0 me-12 radius-8">
                          <span class="text-lg text-secondary-light fw-semibold flex-grow-1">Dianne Russell</span>
                        </div>
                      </td>
                      <td>#6352148</td>
                      <td>iPhone 14 max</td>
                      <td>
                        <a href="" class="btn-primary">edit</a>
                        <a href="" class="btn-danger">delete</a>
                      </td>

                     
                    </tr>
                   
                  </tbody>
                </table>
              </div>
            </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Gisel Overseas\giseloverseas\resources\views/admin/gallery.blade.php ENDPATH**/ ?>