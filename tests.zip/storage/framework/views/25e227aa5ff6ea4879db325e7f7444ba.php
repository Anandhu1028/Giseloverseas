<!doctype html>
<html lang="en">


<head>
	<title>: Gisel  Overseas : Admin </title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Responsive Bootstrap 5 admin dashboard template & web App ui kit.">
	<meta name="keyword" content="bootstrap admin template">

	
<?php echo $__env->make('layouts.admin.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body data-bvite="theme-CeruleanBlue" class="layout-border svgstroke-a layout-default">

    <main class="container-fluid px-0">

        <?php echo $__env->make('layouts.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('layouts.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	

        


        <?php echo $__env->yieldContent('content'); ?>




        <?php echo $__env->make('layouts.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


		<?php echo $__env->make('layouts.admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





    </main>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\Gisel Overseas\giseloverseas\resources\views/layouts/admin/app.blade.php ENDPATH**/ ?>