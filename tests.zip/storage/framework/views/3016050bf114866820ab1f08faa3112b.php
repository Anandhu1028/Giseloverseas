
<?php $__env->startSection('content'); ?>


<div class="section-title parallax-bg parallax-light">
    <ul class="bg-slideshow">
        <li>
            <div style="background-image:url(<?php echo e(asset('assets/media/bg/bg-title.jpg')); ?>)" class="bg-slide"></div>
        </li>
    </ul>
    <div class="section__inner">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <h1 class="ui-title-page">Our services</h1>
                    <div class="ui-subtitle-page"></div>
                    <div class="decor-2 decor-2_mod-a decor-2_mod_white"></div>
                </div><!-- end col -->
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end section__inner -->
</div><!-- end section-title -->


<section class="section-default">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <h2 class="ui-title-block"><span class="ui-title-emphasis">fastest shipping</span>Gisel Overseas</h2>
                <div class="decor-1"><i class='icon flaticon-delivery36'></i></div>
                <div class="ui-subtitle-block ui-subtitle-block_mod-b">Essential Logistics Services in Global Trade</div>
                <div class="text-container text-center">Services play a crucial role in global trade by facilitating the efficient movement of goods across borders through various transportation methods, including air, sea, road, and rail. They ensure timely deliveries, which are essential for maintaining robust supply chains worldwide. These services provide flexible options for both businesses and individuals, accommodating everything from small packages to large shipments, regardless of distance.</div>
            </div>
        </div>
    </div>
</section>


<div class="section-progress clearfix">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                

                <div class="progress-center">
                    <img class="center-block img-responsive" src="<?php echo e(asset('assets/media/bg/bg-1.jpg')); ?>" alt="background">
                    
                </div>
            </div><!-- end col -->
        </div><!-- end row -->
    </div><!-- end container -->
</div><!-- end section-progress -->


<section class="section-area">
    <div class="section-bg_mod-a section-title-block">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <h2 class="ui-title-block"><span class="ui-title-emphasis">main services</span>what we offers</h2>
                    <div class="decor-1"><i class='icon flaticon-delivery36'></i></div>
                </div>
            </div>
        </div>
    </div>

    <div class="section-top-minus section_mod-d">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-4">
                    <article class="post post_mod-b post_mod-b_mg-btn clearfix">
                        <div class="entry-media">
                            <a class="prettyPhoto" href="">
                                <img class="img-responsive" src="<?php echo e(asset($item->img)); ?>"  alt="Foto" style="width: 320px; height: 220px; object-fit: cover;"> 
                            </a>
                        </div>
                        <div class="entry-main" style=" height: 400px; object-fit: cover;">
                            <div class="entry-header">
                                <h2 class="entry-title ui-title-inner"><a href="blog-post.html"><?php echo e($item->headline); ?></a></h2>
                                <div class="decor-2 decor-2_mod-b"></div>
                            </div>
                            <div class="entry-content">
                                <p><?php echo e($item->description); ?></p>
                            </div>
                        </div>
                    </article>
                </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
               
            </div>
        </div>
    </div>
    
</section>


<section class="section-bg">
    <div class="parallax-bg parallax-primary">
        <ul class="bg-slideshow">
            <li>
                <div style="background-image:url(<?php echo e(asset('assets/media/bg/bg-7.jpg')); ?>)" class="bg-slide"></div>
            </li>
        </ul>
    </div>
    
</section>



             

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Gisel Overseas\giseloverseas\resources\views/frontend/service.blade.php ENDPATH**/ ?>