
<?php $__env->startSection('content'); ?>
<div class="container-fluid p-0 mx-auto mt-5" style="max-width: 1140px;">
    <div class="card h-100 p-0 radius-12 overflow-hidden">
        <div class="card-body p-4">
            <div class="bg-primary-50 px-4 py-3 radius-8 mb-6">
                <h6 class="fw-semibold mb-0 text-center"> Edit Item </h6>
             </div>
            <div class="tab-content" id="pills-tabContent">
                <div class="tab-pane fade show active" id="pills-all" role="tabpanel" aria-labelledby="pills-all-tab" tabindex="0">
                    <div class="row gy-4">
                        <div class="col-md-12">
                            <div class="table-responsive">
                                <form class="form-floating" action="<?php echo e(route('admin.gallery_update',['id'=>$gallery->id])); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div style="text-align: right;">
                                        <button type="submit" class="btn btn-primary-100 text-primary-600 radius-8 px-20 py-11 mb-2">Update</button>
                                        <a href="/admin/awards" class="btn btn-primary-100 text-primary-600 radius-8 px-20 py-11 mb-2">Cancel</a>
                                    </div>
                                    <div class="mb-4">
                                        <label for="headline" class="form-label">Headline</label>
                                        <input type="text" class="form-control" id="headline" value="<?php echo e($gallery->headline); ?>" placeholder="Headline" name="headline" required>
                                    </div>
                                    <div class="mb-4">
                                        <label for="description" class="form-label">Description</label>
                                        <textarea class="form-control" id="description" value="<?php echo e($gallery->description); ?>" placeholder="" name="description" required cols="30" rows="5" ><?php echo e($gallery->description); ?></textarea>
                                    </div>
                                    <div class="mb-4">
                                        <span class="form-floating">
                                            <input type="file" class="form-control" id="TextInput" placeholder="img" value="<?php echo e($gallery->img); ?>" name="img" >
                                            <label class="" for="TextInput">Image</label>
                                            <img src="<?php echo e($gallery->img); ?>" alt="" width='100px'>
                                        </span>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Gisel Overseas\giseloverseas\resources\views/admin/gallery/edit.blade.php ENDPATH**/ ?>